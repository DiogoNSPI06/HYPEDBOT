const Discord = require("discord.js")

exports.run = async (client, message, args) => { 
  message.delete();
  const content = args.join(" ");

  if (!args[0]) { 
    return message.channel.send(`${message.author.username}, escreva a sugestão após o comando`) } else if (content.length > 1000) {
      return message.channel.send(`${message.author.username}, forneça ua sugestão de no máximo 1000 caractéres`)    
    } else {
      var canal = message.guild.channels.cache.find(ch => ch.id === "734554309009604688");
      const msg = await canal.send(
        new Discord.MessageEmbed()
        .setcolor("RANDOM")
        .addField("Author:", message.author)
        .addField("Conteúdo", content)
        .setFoooter("ID do Author: " + message.author.id)
        .setTimestamp()
      );
      await message.channel.send(`${message.author}, a mensagem foi enviada com sucesso!`);

      const emojis = ["<a:baiacu:670768109417791498>","<a:pika:670726559111315458>"]

      for (const i in emojis) {
        await msg.react(emojis[i])
      }
    }
 
}

