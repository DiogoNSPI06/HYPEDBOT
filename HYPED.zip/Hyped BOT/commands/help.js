const Discord = require('discord.js');

module.exports.run = async (client, message, args) => {
  const embed = new Discord.MessageEmbed()
    .setTitle(`Utilize: h!ajuda !`)
    .setColor("#2826d4")
  message.channel.send(embed);
};