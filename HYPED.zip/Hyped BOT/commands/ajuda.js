const Discord = require('discord.js');
const c = require('../config.json')

module.exports.run = async (client, message, args) => {
    message.delete()

    const erros = new Discord.MessageEmbed()
        .setAuthor("Equipe HYPED - Erro", client.user.avatarURL)
        .setDescription(`${message.author}, não consigo enviar mensagem para você, ative suas mensagens diretas!`)
        .setTimestamp()
        .setThumbnail(client.user.avatarURL)
        .setFooter(message.author.tag, message.author.avatarURL)
        .setColor('RANDOM')

    const yes = new Discord.MessageEmbed()
        .setAuthor(`${message.guild.name} - Ajuda`)
        .setDescription(` ${message.author}, enviei meus comandos em seu privado!`)
        .setTimestamp()
        .setColor("RANDOM")
        .setFooter(message.author.tag, message.author.avatarURL)
    message.channel.send(yes).then(msg => msg.delete(12000))

    const embed = new Discord.MessageEmbed()
        .setAuthor(`${message.guild.name} - Ajuda`)
        .setDescription(`Para saber meus comandos, reaja ao emoji de cada categoria!
        E Meu Prefixo é "h!"`)
        .addField(`⭐ **Informações**`, '• `ajuda`, `server`, `user`, `sugerir`, `avatar`...')
        .addField(`📥 **Pedidos**`, '• `plugin`, `web`, `outros`...')
        .addField(`👦 **Usuário**`, '• `portfolio`, `recomendações`, `reputação`...')
        .addField(`😂 **Diversão**`, '• `lenny`, `coinflip`, `dados`...')
        .addField(`🎶 **Música**`, '• `play`, `stop`, `skip`, `playlist`...')
        .addField(`🔧 **Staff**`, '• `ban`, `mute`, `chat`, `limpar`...')
        .setFooter(message.author.tag, message.author.avatarURL)
        .setTimestamp()
        .setColor('RANDOM')
    message.author.send(embed).catch(err => message.channel.send(erros)).then(async msg => {
        await msg.react('⭐')
        await msg.react('📥')
        await msg.react('👦')
        await msg.react('😂')
        await msg.react('🎶')
        await msg.react('🔧')
        await msg.react("↩")


        const informacao = (reaction, user) => reaction.emoji.name === '⭐' && user.id === message.author.id;
        const pedidos = (reaction, user) => reaction.emoji.name === '📥' && user.id === message.author.id;
        const usuario = (reaction, user) => reaction.emoji.name === '👦' && user.id === message.author.id;
        const diversao = (reaction, user) => reaction.emoji.name === '😂' && user.id === message.author.id;
        const musica = (reaction, user) => reaction.emoji.name === '🎶' && user.id === message.author.id;
        const staff = (reaction, user) => reaction.emoji.name === '🔧' && user.id === message.author.id;

        const back = (reaction, user) => reaction.emoji.name === "↩" && user.id === message.author.id;

        const informacaoL = msg.createReactionCollector(informacao)
        const usuarioL = msg.createReactionCollector(usuario)
        const pedidosL = msg.createReactionCollector(pedidos)
        const diversaoL = msg.createReactionCollector(diversao)
        const musicaL = msg.createReactionCollector(musica)
        const staffL = msg.createReactionCollector(staff)

        const backL = msg.createReactionCollector(back)


        backL.on('collect', r => {
            const embedd = new Discord.MessageEmbed()
                .setAuthor(`${message.guild.name} - Ajuda`)
                .setDescription(`Para saber meus comandos, reaja ao emoji de cada categoria.`)
                .addField(`⭐ **Informações**`, '• `ajuda`, `server`, `user`, `sugerir`, `avatar`, ...')
                .addField(`📥 **Pedidos**`, '• `plugin`, `web`, `outros`')
                .addField(`👦 **Usuário**`, '• `portfolio`, `recomendações`, `reputação`...')
                .addField(`😂 **Diversão**`, '• `lenny`, `coinflip`, `dados`...')
                .addField(`🎶 **Música**`, '• `Não Funcionando`')
                .addField(`🔧 **Staff**`, '• `ban`, `mute`, `chat`, `limpar`...')
                .setFooter(message.author.tag, message.author.avatarURL)
                .setTimestamp()
                .setColor("RANDOM")
            msg.edit(embedd)
        })

        informacaoL.on('collect', r => {

            const embedinformacao = new Discord.MessageEmbed()
                .setAuthor(`${message.guild.name} - Ajuda`)
                .setDescription(`⭐ **UTEIS**

                h!ajuda - Exibe o menu de ajuda.
                h!serverinfo - Mostra status do servidor.
                h!botinfo - Mostra informações sobre mim.
                h!userinfo - Informações do usuario.
                h!invites - Mostra o rank de convites.
                h!lembrete \`<tempo>\` \`<lembrete>\` - Te lembra de algo importante.
                h!rank - Mostra o rank de XP.
                h!topmoney - Mostra o rank de money.
                h!ping - Mostra o delay bot-servidor.
                h!toprep - Mostra o rank de recomendações.
                h!imgur \`<img>\` - Faz upload de uma imagem para o Imgur.
                h!uptime - o horário em que eu acordei!


         `)
                .setColor("RANDOM")
                .setFooter(message.author.tag, message.author.avatarURL)
                .setTimestamp()
            msg.edit(embedinformacao)
        })

        pedidosL.on('collect', r => {

            const embedpedidos = new Discord.MessageEmbed()
                .setAuthor(`${message.guild.name} - Ajuda`)
                .setDescription(`📥 **PEDIDOS**

                h!plugin - Faça um pedido relacionado a plugins!
                h!web - Faça um pedido relacionado a web!
                h!outros - Faça um pedido de algo não listado!
         `)
                .setColor("RANDOM")
                .setFooter(message.author.tag, message.author.avatarURL)
                .setTimestamp()
            msg.edit(embedpedidos)
        })

        usuarioL.on('collect', r => {
            const embedusuario = new Discord.MessageEmbed()
                .setAuthor(`${message.guild.name} - Ajuda`)
                .setDescription(`👦 **USUARIO**
                        
                h!apresentar - Apresente-se em nosso servidor.
                h!setportfolio \`<url>\` - Adiciona ou altera o link do seu portfolio.
                h!recomendações - Mostra seus pontos de recomendação.
                h!recomendar - \`<@user>\` - Recomende um usuário.

        `)
                .setColor("RANDOM")
                .setFooter(message.author.tag, message.author.avatarURL)
                .setTimestamp()
            msg.edit(embedusuario)
        })

        diversaoL.on('collect', r => {
            const embeddiversao = new Discord.MessageEmbed()
                .setAuthor(`${message.guild.name} - Ajuda`)
                .setDescription(`😂 **DIVERSÃO**
                        
                h!dados \`<quantidade>\` - Joga até 5 dados na mesa.
                h!coinflip - Joga moeda para cima.
                h!emojify \`<texto>\`- Transforma seus textos em emojis.
                h!random - Mostra aleatoriamente um número.
                h!say \`<mensagem>\` - Faz com que eu repita uma frase.
                h!aquelacarinha - Aquela carinha. ( ͡ʘ ͜ʖ ͡ʘ)
                h!guess - Acerte o número aleatório em 10 tentativas.
                h!8ball \`<mensagem>\` - Responde suas perguntas.
                h!biscoito \`<usuário>\` - Da um biscoito para um usuário. 🍪
                h!tapa \`<usuário>\` - Da um tapa em um usuário.
                h!morse \`<mensagem>\` - Transforma um texto em código morse.
                h!hex \`<código hex>\` - Mostra o hex e o rgb de uma cor.
                h!dog - Mostra uma imagem fofinha de cachorro.
                h!cat - Mostra uma imagem fofinha de gato.
                h!triggerd \`<usuário>\` - Deixa um usuário irritado.
                h!primeiraspalavras \`<mensagem>\` - Cria o meme das primeiras palavras.

        `)
                .setColor("RANDOM")
                .setFooter(message.author.tag, message.author.avatarURL)
                .setTimestamp()
            msg.edit(embeddiversao)
        })

        musicaL.on('collect', r => {
            const embeddiversao = new Discord.MessageEmbed()
                .setAuthor(`${message.guild.name} - Ajuda`)
                .setDescription(`🎶 **Música**
                Não Funcionando!
                EM BETA!!!!
        `)
                .setColor("RANDOM")
                .setFooter(message.author.tag, message.author.avatarURL)
                .setTimestamp()
            msg.edit(embeddiversao)
        })

        staffL.on('collect', r => {
            const embeddiversao = new Discord.MessageEmbed()
                .setAuthor(`${message.guild.name} - Ajuda`)
                .setDescription(`🔧 **Staff**

                h!clear <1-99>- Limpa as mensagens!
                h!denunciar - Denuncia um mebro       
                h!ban \`<usuário>\` \`<razão>\` - Bane um usuário.
                h!mute \`<usuário>\` \`<tempo>\` \`<razão>\` - Muta um usuário por certo tempo.
                h!unban \`<usuário>\` - Desbane um usuário.
                h!unmute \`<usuário>\` - Desmuta um usuário.
                h!listban - Envia no privado uma lista dos usuários banidos do servidor.
                h!spacemychannel \`<canal>\` - Remove hifens do nome de um canal.
                h!embed \`<mensagem>\` - Cria um embed apartir de uma mensagem.
                h!rolemention \`<id do cargo>\` - Muda o status de um cargo de não-mencionavel para mencionavel por 15 segundos.
                h!serverinfo - informações do servidor!
                h!userinfo - informações do usuario!
                h!botinfo - informações do BOT!
 
        `)
                .setColor("RANDOM")
                .setFooter(message.author.tag, message.author.avatarURL)
                .setTimestamp()
            msg.edit(embeddiversao)
        })

    })
}

exports.help = {
    name: "ajuda",
    aliases: ['help']
}